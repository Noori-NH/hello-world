package com.musichub.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller

public class HandleController {
	
	
		@RequestMapping("/")
		public ModelAndView helloWorld() {
	 
			
			return new ModelAndView("index");
		}
		
		@RequestMapping("/index")
		public String goToIndex()
		{
			return "index";
		}
		
		
		@RequestMapping("/login")
		public String goToLogin()
		{
			return "login";
		}
		
		@RequestMapping("/register")
		public String goToRegister()
		{
			return "register";
		}
		@RequestMapping("/product")
		public String goToProduct(HttpServletRequest re)
		{
			String val=re.getParameter("s");
			System.out.println("value="+val);
			re.setAttribute("val", val);
			return "product";
		}
		@RequestMapping("/aboutus")
		public String goToAboutus()
		{
			return "aboutus";
		}
}



	      
	


