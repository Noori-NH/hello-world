package com.musichub.dao;

import java.lang.reflect.Type;
import java.util.LinkedList;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.musichub.model.Product;

public class Data implements Service {
	Product p1,p2,p3;
	LinkedList<Product> ls;
public Data() {
		//super();
	ls=new LinkedList<>();
	}



@Override
public List<Product> all() {
	// TODO Auto-generated method stub
	p1=new Product("1234","Saxophone59",89766.90,"saxophone");
	p2=new Product("4034","Electric guitar02",59700.00,"eguitar");
	p3=new Product("8049","Piano55",99000.00,"piano");
	ls.add(p1);
	ls.add(p2);
	ls.add(p3);
	 return ls;
}

}
