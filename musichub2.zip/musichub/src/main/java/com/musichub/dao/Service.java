package com.musichub.dao;

import java.util.List;

import com.musichub.model.Product;

public interface Service {

public List<Product> all();
}
