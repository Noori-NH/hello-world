package com.musichub.controller;

import java.lang.reflect.Type;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.musichub.dao.Data;
import com.musichub.model.Product;

@Controller

public class HandleController {
	
	Data d;
	Product p;
	List<Product> ls;
		@RequestMapping("/")
		public ModelAndView helloWorld() {
	 
			
			return new ModelAndView("index");
		}
		
		@RequestMapping("/index")
		public String goToIndex()
		{
			return "index";
		}
		
		
		@RequestMapping("/login")
		public String goToLogin()
		{
			return "login";
		}
		
		@RequestMapping("/register")
		public String goToRegister()
		{
			return "register";
		}
		//@RequestMapping(value="/product",method = RequestMethod.GET,produces =                  {"application/json"})
     
		@RequestMapping("/product")
		public  ModelAndView goToProduct(HttpServletRequest re)
		{
			String val=re.getParameter("s");
			System.out.println("value="+val);
			re.setAttribute("val", val);
		
			d=new Data();
			ls=(List<Product>)d.all();
			Gson gson = new Gson();
		      String jsonProducts = gson.toJson(ls);
		      System.out.println("jsonProducts = " + jsonProducts);

		      //
		      // Converts JSON string into a collection of Student object.
		      //
		    /*  Type type = new TypeToken<List<Product>>() {
		      }.getType();
		      List<Product> pList = gson.fromJson(jsonProducts, type);
			Iterator it=ls.iterator();
			while(it.hasNext())
			{
				p=(Product)it.next();
				System.out.println("p_code="+p.getP_code()+":p_name="+p.getP_name()+":p_price="+p.getP_price()+"link="+p.getLink());
			}*/
			ModelAndView mv=new ModelAndView("product");
			mv.addObject("data", jsonProducts);
			return mv;
		}
		@RequestMapping("/aboutus")
		public String goToAboutus()
		{
			return "aboutus";
		}
		@RequestMapping("/addcart")
		public String goToAddCart(HttpServletRequest re)
		{
			String s=re.getParameter("a");
			re.setAttribute("cart", s);
			return "addcart";
		}
}



	      
	


