
var val=${data};
angular.module('myApp',[]).controller('cust1', function($scope) {

	$scope.ddddd=data;

});
